

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kev
 */
public class MyDbConnection {
    static Connection con;
    
    public static Connection getConnection() throws ClassNotFoundException{
        
          try{
              Class.forName("com.mysql.jdbc.Driver");  
              con=DriverManager.getConnection("jdbc:mysql://localhost:3307/housetax","root","keshav");  
              //here sonoo is database name, root is username and password  
              /*Statement stmt=con.createStatement();  
              ResultSet rs=stmt.executeQuery("select * from Housetax");  
              while(rs.next())  
              System.out.println(rs.getInt(1)+"  "+rs.getString(2));  
              con.close();  
            }
*/}
catch(Exception e){
                System.out.println(e);
            }
          return con;
    }
    
    public static boolean checkLogin(String user, String pwd) {
        try {
            Connection con=getConnection();
            PreparedStatement ps=con.prepareStatement("select custid from housetax where custid=? and password=?");
            ps.setString(1, user);
            ps.setString(2, pwd);
            return ps.executeQuery().next();
        }
        catch(Exception e) {
            System.out.println(e);
            return false;
        }
    }
    public static void main(String gh[]) throws ClassNotFoundException {
    System.out.println(getConnection());
}
}